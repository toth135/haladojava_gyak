package hu.me.student_university.dao;

import hu.me.student_university.entity.UniversityEntity;
import org.springframework.data.repository.CrudRepository;

public interface UniversityCrudRepository extends CrudRepository<UniversityEntity, Long> {
}
