package hu.me.student_university.service;

import hu.me.student_university.entity.StudentEntity;

public interface StudentService {

    Iterable<StudentEntity> getStudents();

}
