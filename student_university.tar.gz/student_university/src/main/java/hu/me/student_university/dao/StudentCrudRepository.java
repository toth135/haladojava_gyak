package hu.me.student_university.dao;

import hu.me.student_university.entity.StudentEntity;
import org.springframework.data.repository.CrudRepository;

public interface StudentCrudRepository extends CrudRepository<StudentEntity, Long> {
}
