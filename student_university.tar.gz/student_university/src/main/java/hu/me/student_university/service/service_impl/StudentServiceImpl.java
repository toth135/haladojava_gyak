package hu.me.student_university.service.service_impl;

import hu.me.student_university.dao.StudentCrudRepository;
import hu.me.student_university.entity.StudentEntity;
import hu.me.student_university.service.StudentService;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService {

    StudentCrudRepository studentCrudRepository;

    @Override
    public Iterable <StudentEntity> getStudents() {
        return studentCrudRepository.findAll();
    }

}
